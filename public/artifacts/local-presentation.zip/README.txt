NYU Sociology — AI for research

Run: python3 serve.py
Open: http://127.0.0.1:8765

No Internet or AI API is required. Do not open index.html with file://.
Open the PDF slides from the index. Each research output opens directly.
The complete PDF backup and research archive are in site/artifacts/.
Recordings replay actual command output; timing is adjusted for readability.
The current study protocol is a proposal, not an empirical estimate. The original model remains archived.
