from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from functools import partial
from pathlib import Path
root=Path(__file__).resolve().parent/'site'
server=ThreadingHTTPServer(('127.0.0.1',8765),partial(SimpleHTTPRequestHandler,directory=str(root)))
print('Open http://127.0.0.1:8765 in your browser. Ctrl+C stops the server.',flush=True)
try: server.serve_forever()
except KeyboardInterrupt: server.server_close()
